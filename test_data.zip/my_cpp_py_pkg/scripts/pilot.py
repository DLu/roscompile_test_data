#!/usr/bin/env python3

from my_cpp_py_pkg.pilot import main
main()