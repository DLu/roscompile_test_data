#include <ros/ros.h>
#include <simple_msg_lib/Simple.h>

class Awesome
{
  simple_msg_lib::Simple msg;
};
