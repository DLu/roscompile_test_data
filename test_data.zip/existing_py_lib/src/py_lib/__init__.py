import rospy

def initialize():
    rospy.init_node('a')
