#include <ros/ros.h>
#include <simple_msg/Simple.h>

class Awesome
{
  simple_msg_lib::Simple msg;
};
