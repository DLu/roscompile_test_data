#include <ros/ros.h>
#include <simple_msg_var/Simple.h>

class Awesome
{
  simple_msg_var::Simple msg;
};
